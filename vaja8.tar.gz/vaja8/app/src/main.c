#include <asf.h>
#include <delay.h>
#include <test-more.h>
#include <ioport.h>
#include <lcd.h>
#include <adc.h>
#include <tc.h>
#include <dacc.h>
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif
#define LED_L_PORT PIOB
#define LED_L_PIN PIO_PB27

#define L1_IDX PIO_PC26_IDX

uint_fast32_t n; //do kok steje timer - mora bit nujno uint_FAST32
int vrednost=0;


#define NS 100 /* število vzorcev */
int sinus[NS]; /* tabela vzorcev sinusnega signala */
int triang[NS]; /* tabela vzorcev trikotnega signala */
bool oblika_signala=0;


int main (void)
{

    /* sets the processor clock according to conf_clock.h definitions */
    sysclk_init();

    /* disable wathcdog */
    WDT->WDT_MR = WDT_MR_WDDIS;

    /********************* HW init     ***************************/

    /* ************************ VAJA 8 - DA pretvornik *****************/
    ioport_init();
    init_btn_leds();
    lcd_init();

    // nastavitev timerja
    NVIC_EnableIRQ(TC0_IRQn);
    sysclk_enable_peripheral_clock(ID_TC0);
    tc_init(TC0, 0, TC_CMR_TCCLKS_TIMER_CLOCK3 | TC_CMR_WAVE | TC_CMR_WAVSEL_UP_RC);
    tc_enable_interrupt(TC0, 0, TC_IER_CPCS);

    //nastavitev DA konverterja
    sysclk_enable_peripheral_clock(ID_DACC);
    dacc_reset(DACC);
    dacc_set_transfer_mode(DACC, DACC_MR_WORD_HALF);
    dacc_set_timing(DACC, 0x08, 0, 0x10); /* refresh, max speed, startup time */
    dacc_set_channel_selection(DACC, 1);
    dacc_enable_channel(DACC, 1);


    // tabeliranje sinusa in trikotnika
    for (int i=0; i<NS; i++){
        triang[i] = 4095 * i / (NS-1); // tabeliranje trikotnika
        sinus[i] = 4095 * (sin( 3.14 / 2 * (NS-1 + 2*i) / (NS-1) ) + 1) / 2; // tabeliranje sinusa
    }


    uint32_t f = 5; //Hz
    n = SystemCoreClock/32/f/(2*NS-2); //do kok steje timer - mora bit nujno uint_FAST32

    tc_write_rc(TC0, 0, n);
    tc_start(TC0, 0);

    init_btn_leds(); // funkcija k smo jo napisal na 2 vaji da inicializira ledice
    adc_setup();


    /********************* Main loop     ***************************/
    while(1)
    {

    /* ************************ VAJA 8 - DA pretvornik *****************/

    int fronte = get_btn_press();
    uint32_t potenciometer = adc_read();
    f = 30 * potenciometer / 4095 + 1;  //30 je max frekvenca, +1 je zato ker drgac ko prides na 0Hz ne mores vec nazaj zvisat

    if ( (fronte & (1<<0) ) != 0){
        oblika_signala = !oblika_signala;
    }

    n = SystemCoreClock/32/f/(2*NS - 2); // ta 2 ns je zato ker mamo v tabeli pol periode

    int presledek = sprintf(lcd_string, "Frekvenca: %2lu Hz", f);
    lcd_string[presledek] = ' ';
    if (oblika_signala){
        int presledek = sprintf(lcd_string+16, "Signal: sinus");
        lcd_string[presledek+16] = ' ';
        lcd_driver();
    }
    else{
        int presledek = sprintf(lcd_string+16, "Signal: trikot");
        lcd_string[presledek+16] = ' ';
        lcd_driver();
    }

    //sprintf(lcd_string+11, "%4lu", potenciometer);
    lcd_driver();
    }

    /*************** varnost **************/
    while(1){
    }

}

void TC0_Handler(void){
    // ISR prekinitvena rutina
    tc_get_status(TC0, 0);
    static int gor_dol = 1;

    if ((dacc_get_interrupt_status(DACC) & DACC_ISR_TXRDY)==1){ // pisemo lahko le ko je DAC pripravljen
        if (oblika_signala){
            dacc_write_conversion_data(DACC, sinus[vrednost]);
        }
        else{
            dacc_write_conversion_data(DACC, triang[vrednost]);
        }

        vrednost=vrednost+gor_dol; // da se izrise simetricni signal, ker mamo v tabeli samo pol periode
        if(vrednost==(NS-1)){
            gor_dol = -1;
        }
        if(vrednost==0){
            gor_dol = 1;
        }
        tc_write_rc(TC0, 0, n); //n - do kok steje timer - mora bit nujno uint_FAST32
    }

}


#ifdef __cplusplus
}
#endif
