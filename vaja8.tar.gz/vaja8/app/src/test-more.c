#include <test-more.h>
#include <ioport.h>
#include <pio.h>
#include <asf.h>
#include <adc.h>




void adc_setup(void){
    sysclk_enable_peripheral_clock(ID_ADC);
    adc_init(ADC, 512, 6400000, ADC_STARTUP_TIME_4);
    adc_configure_timing(ADC, 0,ADC_SETTLING_TIME_3 ,1);
    adc_set_resolution(ADC, ADC_12_BITS );
    adc_configure_trigger(ADC, ADC_TRIG_SW,0);
    adc_enable_channel(ADC, ADC_CHANNEL_7);
}

uint32_t adc_read(void){


// sprozi ad pretvornik, pocaka na rezultat:
//1. DRDY bit v ISR -> adc_get_latest_value()
//2. E0C7 bit v ISR -> adc_get_CHANNEL_value()



 adc_start(ADC);

 uint32_t out=0;

    do{
    out=adc_get_status(ADC);}
    while( !(out & ADC_ISR_DRDY));

    return adc_get_latest_value(ADC);




}


void init_btn_leds(void){
    /* definiraj pine za tipke */

    ioport_init();


    ioport_enable_pin(Tip1_IDX);
    ioport_set_pin_dir(Tip1_IDX , IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tip1_IDX , IOPORT_MODE_PULLUP|IOPORT_MODE_DEBOUNCE);
    pio_set_debounce_filter(PIOC,(1<<29)|(1<<21),10);

    ioport_enable_pin(L1_IDX);
    ioport_set_pin_dir(L1_IDX , IOPORT_DIR_OUTPUT);
    ioport_set_pin_mode(L1_IDX , IOPORT_MODE_PULLUP);


    ioport_enable_pin(Tip2_IDX);
    ioport_set_pin_dir(Tip2_IDX , IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tip2_IDX , IOPORT_MODE_PULLUP|IOPORT_MODE_DEBOUNCE);


    ioport_enable_pin(L2_IDX);
    ioport_set_pin_dir(L2_IDX , IOPORT_DIR_OUTPUT);
    ioport_set_pin_mode(L2_IDX , IOPORT_MODE_PULLUP);
    ioport_set_pin_level(L2_IDX, 0);

    ioport_enable_pin(Tip3_IDX);
    ioport_set_pin_dir(Tip3_IDX , IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tip3_IDX , IOPORT_MODE_PULLUP|IOPORT_MODE_DEBOUNCE);


    ioport_enable_pin(L3_IDX);
    ioport_set_pin_dir(L3_IDX , IOPORT_DIR_OUTPUT);
    ioport_set_pin_mode(L3_IDX , IOPORT_MODE_PULLUP);
    ioport_set_pin_level(L3_IDX, 0);

    ioport_enable_pin(Tip4_IDX);
    ioport_set_pin_dir(Tip4_IDX , IOPORT_DIR_INPUT);
    ioport_set_pin_mode(Tip4_IDX , IOPORT_MODE_PULLUP|IOPORT_MODE_DEBOUNCE);


    ioport_enable_pin(L4_IDX);
    ioport_set_pin_dir(L4_IDX , IOPORT_DIR_OUTPUT);
    ioport_set_pin_mode(L4_IDX , IOPORT_MODE_PULLUP);
    ioport_set_pin_level(L4_IDX, 0);

}

int get_btn_state(void){
    int out =0;
    /*vrne int
        bit0 => 1 ce T1 pritisnjena

        */

        if(ioport_get_pin_level(Tip1_IDX) == 0){
        out = out | (1<<0);
        }

        if(ioport_get_pin_level(Tip2_IDX) == 0){
        out = out | (1<<1);
        }

        if(ioport_get_pin_level(Tip3_IDX) == 0){
        out = out | (1<<2);
        }

        if(ioport_get_pin_level(Tip4_IDX) == 0){
        out = out | (1<<3);
        }


    return out;
}

int get_btn_press(void){
    /* vrne int
        bit0 => 1 ce fronta na T1
        bit1 */

        int out=0;
        static int btn_old=0;
        int btn = get_btn_state();

        for(int i=0;i<4;i++){
            if(!(btn_old &(1<<i))    &&   (btn & (1<<i))){
                out = out | (1<<i);
            }
        }

        // ce je bit0 v btn na 1 in bit0 v btn old na 0 -> postavi bit0 v out

        btn_old=btn;
        return out;
}



